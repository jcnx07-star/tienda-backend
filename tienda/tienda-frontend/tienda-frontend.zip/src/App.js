import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [productos, setProductos] = useState([]);
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8081/productos').then(res => setProductos(res.data));
    axios.get('http://localhost:8081/usuarios').then(res => setUsuarios(res.data));
  }, []);

  return (
    <div style={{ margin: '20px', fontFamily: 'Arial' }}>
      <h1>Tienda Virtual</h1>

      <h2>Productos</h2>
      <ul>
        {productos.map(p => (
          <li key={p.id}>{p.nombre} - Q{p.precio} ({p.stock} disponibles)</li>
        ))}
      </ul>

      <h2>Usuarios</h2>
      <ul>
        {usuarios.map(u => (
          <li key={u.id}>{u.nombre} - {u.correo}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
